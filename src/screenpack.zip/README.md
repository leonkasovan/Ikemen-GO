# Ikemen_GO-Elecbyte-Screenpack
Electbyte's Mugen screenpack and font files with some modifications for Ikemen GO

# Licence
Electbyte's Mugen screenpack and font files are licensed under a  
Creative Commons 3.0 Non-commercial License, with optional attribution.  
http://creativecommons.org/licenses/by-nc/3.0/

----------------------------------------------------------------------------

Work contributed to Ikemen GO by various artists is licensed under a  
Creative Commons Attribution 3.0 Unported License.  
http://creativecommons.org/licenses/by/3.0/deed.en_US  
The license applies to following assets:  
- Lifebar messages, rank backgrounds and icons by President Devon and Rurouni  
- Command list glyphs by Rurouni  
- Dizzy, guard break, tag switch effects by Shiyo Kakuge
